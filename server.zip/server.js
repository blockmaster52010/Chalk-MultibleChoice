import chalk from "chalk"
import inquirer from 'inquirer';
import gradient from 'gradient-string'
import chalkAnimation from 'chalk-animation'
import figlet from 'figlet'
console.log(chalk.bgGreen("kddkmddffcfcfvhvcfuvxivhisdfxvkdfxviuhfv"))
//Function that allows you to control timing
function sleep(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }
  let multichoice = chalk.white("Multible Choice Question!!!")
  let awnsers = await inquirer.prompt({
    name: 'player',
    type: 'list',
    message: "What is the atomic number of plutonium?",
    choices: ["92", "94", "86"],
    default(){
        return 'Random Guy'
    },})
    if (awnsers.player == "94"){
      let animation1 = chalkAnimation.rainbow("Correct!")
      await sleep(3000)
      animation1.stop()
    }
    else{
      let animation2 = chalkAnimation.pulse("Wrong!!!")
      await sleep(3000)
      animation2.stop()
    }
  await sleep(3000)